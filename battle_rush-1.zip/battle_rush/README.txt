style.css and script.js are referenced by the provided HTML but their contents were not supplied.
